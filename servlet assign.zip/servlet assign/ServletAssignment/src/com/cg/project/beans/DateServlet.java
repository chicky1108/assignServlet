package com.cg.project.beans;
 
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Date;
 
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
 @WebServlet("/dateServlet")
public class DateServlet 
extends HttpServlet
{	private static final long serialVersionUID = 1L;

	@Override
	protected void doGet(HttpServletRequest req, 
                         HttpServletResponse resp)
	throws ServletException, IOException 
	{
 
		System.out.println("Inside Get() Method ...");
 
		//Java Code to Generate Current Date & Time
		Date dateRef = new Date();
		String currentDate = dateRef.toString();
 
		resp.setContentType("text/html");
		PrintWriter out=resp.getWriter();
 
		out.print("<b>Today's date</b>: "+currentDate);
 
 
	}//End of Get method
 
}//End of Class